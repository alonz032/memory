#include <iostream>
#include <string>
#include <ctime>   // For time()
#include <cstdlib> // For rand() and srand()

class Exam {
    private:
        std::string examName;
        double** examScores; 
        int capacity;        
        int size;           

    public:
        Exam(std::string name, int cap) : examName(name), capacity(cap), size(0) {
            examScores = new double*[capacity];
        }
        std::string getName() const { return examName; }
        int getSize() const { return size; }
        int getCapacity() const { return capacity; }

        void addScore(double score) {
            if (size == capacity) resize(capacity * 2); 
            
            examScores[size] = new double(score);
            size++;
        }

        void resize(int newCap) {
            std::cout << "\n[!] Expanding " << examName << " to capacity: " << newCap << "...\n";
            double** newArray = new double*[newCap];

            for (int i = 0; i < size; i++) {
                newArray[i] = examScores[i];
            }
            
            examScores = newArray; 
            capacity = newCap;
        }

        
        void display() {
            std::cout << "\n--- " << examName << " Gradebook ---" << std::endl;
            for (int i = 0; i < size; i++) {
                std::cout << "Student " << i + 1 << ": " << *examScores[i] << "%" << std::endl;
            }
            std::cout << "------------------------------" << std::endl;
        }
};
int main() {
    srand(time(0)); // Seed the rng
    
    // Start with a small capacity of 10
    Exam biology("Bio 101", 10);
    Exam math("Math 101", 10);

    std::cout << "Adding 100 random student scores (60% to 95%)...\n";

    for (int i = 0; i < 100; i++) {
        // Generate random double between 60.0 and 95.0
        double randomScore = 60.0 + (rand() % 351) / 10.0; 
        biology.addScore(randomScore);
    }

    for (int i = 0; i < 100; i++) {
        // Generate random double between 60.0 and 95.0
        double randomScore = 60.0 + (rand() % 351) / 10.0; 
        math.addScore(randomScore);
    }

    std::cout << "\nDone. Final Capacity: " << biology.getCapacity() << "\n";
    std::cout << "Total Leaks: Since we started at 10 and ended at 160, ";
    std::cout << "we abandoned 4 different arrays in RAM." << std::endl;

    biology.display();
    math.display();

    return 0;
}
